<!doctype html>
<html><head>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>组织信息</title>
    <link rel="stylesheet" href="/css/main/ui.css">


</head>
<body>
<div class="fn-pl40 fn-pr40 fn-pt30 fn-pb30 fn-clear">
    <div class="pz-form">
        <form id="j-editform">
            <div class="wrap fn-clear fn-pb20">
                <div class="group2">
                    <div class="formtitle fn-mb15">基本信息</div>
                    <div class="row row100">
                        <div class="row-title">机构全称</div>
                        <div class="row-content" data-field="orgName"><input type="text" value="内江日报" name="orgName" class="disabled" disabled=""></div>
                    </div>
                    <div class="row row100">
                        <div class="row-title">机构昵称</div>
                        <div class="row-content" data-field="orgAlias"><input type="text" maxlength="20" value="“i内江”手机客户端" name="orgAlias"></div>
                    </div>
                    <div class="row row100">
                        <div class="row-title">LOGO</div>
                        <div class="row-content">
                            <div id="j-cover" class="xcy-cutimg">
                                <label class="upbtn">
                                    <div class="imgbar fn-textleft">
                                        <span class="close"><i class="pz-icon icon-close"></i></span>
                                        <span class="logo"><img src="https://xcycdn.zhongguowangshi.com///live-img/20170706/1499333599494_55.png"></span>
                                    </div>
                                    <div class="fn-pt25">
                                        <i class="pz-icon icon-img"></i>
                                        <p class="fn-textcenter fn-mt5">点击选择LOGO图标</p>
                                    </div>
                                    <div class="j-file-input fn-hide">
                                        <input type="file" accept="image/gif,image/jpeg,image/jpg,image/png">
                                    </div>
                                </label>
                            </div>
                            <div class="fn-mt5 pz-color-gray">支持88px*88px图片大小</div>
                        </div>
                    </div>
                    <div class="formtitle fn-mt20 fn-mb15">推广设置<em class="fn-ml10 fn-fs12 pz-color-gray">若您需要在H5页面推广新的APP，可进行以下设置</em></div>
                    <div class="row row100">
                        <div class="row-title">客户端名称</div>
                        <div class="row-content" data-field="downloadTitle"><input type="text" maxlength="11" value="i内江" name="downloadTitle" placeholder="最长支持11个字符"></div>
                    </div>
                    <div class="row row100">
                        <div class="row-title">推广标语</div>
                        <div class="row-content" data-field="downloadDesc"><input type="text" maxlength="16" value="爱内江，就看“i内江”" name="downloadDesc" placeholder="最长支持16个字符"></div>
                    </div>
                    <div class="row row100">
                        <div class="row-title">安卓下载地址</div>
                        <div class="row-content" data-field="androidDownload"><input type="text" maxlength="200" value="http://v.scnjnews.com/app/app.html" name="androidDownload" placeholder="Android下载地址"></div>
                    </div>
                    <div class="row row100">
                        <div class="row-title">iOS下载地址</div>
                        <div class="row-content" data-field="iosDownload"><input type="text" maxlength="200" value="http://v.scnjnews.com/app/app.html" name="iosDownload" placeholder="iOS下载地址"></div>
                    </div>
                </div>
                <div class="group2 fn-pl40 fn-clear">
                    <div class="fn-left fn-pl15 fn-pr15 fn-pb30" style="background:#f1f5fc;color:#717f9c;">
                        <div class="fn-mb20" style="line-height:40px;">效果预览：</div>
                        <div style="position:relative;">
                            <div id="j-view-logo" style="position:absolute;width:42px;height:42px;overflow:hidden;left:58px;top:246px;"><img src="https://xcycdn.zhongguowangshi.com///live-img/20170706/1499333599494_55.png" width="100%"></div>
                            <div id="j-view-title" class="fn-ellipsis fn-fs16" style="position:absolute;width:180px;left:110px;top:246px;color:#fff;">i内江</div>
                            <div id="j-view-desc" class="fn-ellipsis fn-fs12" style="position:absolute;width:180px;left:110px;top:270px;color:#9b9b9b;">爱内江，就看“i内江”</div>
                            <img src="/static/imgs/orginfo.png">
                        </div>
                    </div>
                </div>
            </div>
            <div class="actions actions-transparent fn-pt20">
                <input type="submit" class="pz-btn btn-success btn-big" value="保存修改">
            </div>
        </form>
    </div>
</div>
>

<div class="fn-hide"><iframe id="j-tplFrame" src="/pizza/tpl/../../cutimg.html?callback=tplCallback1505534587638"></iframe></div></body></html>