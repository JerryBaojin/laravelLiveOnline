<html><head>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>现场管理</title>
    <link rel="stylesheet" href="/css/main/ui.css">

</head>
<body>
<div id="j-list" class="fn-pt30 fn-pb30 fn-pl40 fn-pr40">   <div class="fn-fs14" style="color:#666;">当前正在直播的现场</div>   <div class="pz-table fn-mt10">     <table class="table-noborder table-noheader">              <tbody><tr>         <td>内江市第86个“九·一八”纪念日活动(直播)</td>         <td>大海</td>         <td class="fn-textcenter">2017-09-15 22:56</td>         <td class="fn-textcenter">           <a class="j-get" href="javascript:void(0)" data-id="150548741286080" data-title="内江市第86个“九·一八”纪念日活动(直播)">发布报道</a>         </td>       </tr>              <tr>         <td>四川省2017年国家网络安全宣传周(直播)</td>         <td>大海</td>         <td class="fn-textcenter">2017-09-15 22:33</td>         <td class="fn-textcenter">           <a class="j-get" href="javascript:void(0)" data-id="150548598073563" data-title="四川省2017年国家网络安全宣传周(直播)">发布报道</a>         </td>       </tr>            </tbody></table>   </div>   </div>


</body></html>