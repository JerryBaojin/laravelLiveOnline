9.26
  sceneList has not support delete the scen;
  the searchBox is not aviliable;
