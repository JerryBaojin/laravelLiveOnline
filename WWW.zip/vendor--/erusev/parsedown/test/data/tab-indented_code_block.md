	<?php
	
	$message = 'Hello World!';
	echo $message;

	echo "following a blank line";